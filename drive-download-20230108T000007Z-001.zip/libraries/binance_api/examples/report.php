<?php

require 'php-binance-api.php';

$api = new Binance\API();
$api->report();
